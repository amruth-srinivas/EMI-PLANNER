package com.example.splashscreen;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class breakups extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_breakups);
        Intent intent= getIntent();
        String msg= intent.getStringExtra("msg");
        String breakup= intent.getStringExtra("breakup");
        TextView result=findViewById(R.id.tvresult);
        TextView result2=findViewById(R.id.tvresult2);
        result.setText(msg);
        result2.setText(breakup);

    }
}