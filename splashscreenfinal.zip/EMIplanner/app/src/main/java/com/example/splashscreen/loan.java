package com.example.splashscreen;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class loan extends AppCompatActivity {
    private Button btnloan;

    //Declaring variables
    EditText etsalary, etroi, etexpense, ettime;
    TextView tvsalary, tvroi, tvexpense, tvrlt, tvtime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loan);

        // Binding so that XML resources are available in Java File
        etsalary = findViewById(R.id.etsalary);
        etroi = findViewById(R.id.etroi);
        etexpense = findViewById(R.id.etexpense);
        ettime = findViewById(R.id.ettime);
        tvsalary = findViewById(R.id.tvsalary);
        tvroi = findViewById(R.id.tvroi);
        tvexpense = findViewById(R.id.tvexpense);
        tvtime = findViewById(R.id.tvtime);
        tvrlt = findViewById(R.id.tvrlt);
        btnloan = findViewById(R.id.btnloan);

        // Button Calculate EMI
        btnloan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (etsalary.getText().toString().equals("") || etroi.getText().toString().equals("") || etexpense.getText().toString().equals("")) {
                    Toast.makeText(loan.this, "Please insert valid numbers!", Toast.LENGTH_SHORT).show();
                } else {
                    // Getting input from the user
                    // Getting input from the user
                    float monthlySalary = Float.parseFloat(etsalary.getText().toString());
                    float interestRate = Float.parseFloat(etroi.getText().toString());
                    float expenses = Float.parseFloat(etexpense.getText().toString());
                    float time = Float.parseFloat(ettime.getText().toString());

                    // Calculate available loan amount
                    float monthlyExpense = expenses;
                    float monthlyInterest = interestRate / 100;
                    float loanAmount = (monthlySalary - monthlyExpense) * (float) Math.pow(1 + monthlyInterest, time) / ((float) Math.pow(1 + monthlyInterest, time) - 1);

                    // Calculate EMI
                    float emi = loanAmount * monthlyInterest * (float) Math.pow(1 + monthlyInterest, time) / ((float) Math.pow(1 + monthlyInterest, time) - 1);

                    // Display the result
                    String result = "Possible loan amount: " + loanAmount + "\nEMI to be paid: " + emi;
                    tvrlt.setText(result);

                }
            }

        });

    }
}