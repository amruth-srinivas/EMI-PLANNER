package com.example.splashscreen;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class calculateemi extends AppCompatActivity {
    private Button btnEmi;

    //Declaring variables
    EditText etprinciple, etrate, ettenure;
    TextView tvprinciple, tvrate, tvtenure;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculateemi);

        // Binding so that XML resources are available in Java File
        etprinciple = findViewById(R.id.etprinciple);
        etrate = findViewById(R.id.etrate);
        ettenure = findViewById(R.id.ettenure);
        tvprinciple = findViewById(R.id.tvprinciple);
        tvrate = findViewById(R.id.tvrate);
        tvtenure = findViewById(R.id.tvtenure);
        btnEmi = findViewById(R.id.btnEmi);

        // Button Calculate EMI
        btnEmi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (etprinciple.getText().toString().equals("") || etrate.getText().toString().equals("") || ettenure.getText().toString().equals("")) {
                    Toast.makeText(calculateemi.this, "Please insert valid numbers!", Toast.LENGTH_SHORT).show();
                } else {
                    // Getting input from the user
                    float loan = Float.parseFloat(etprinciple.getText().toString());
                    float rate = Float.parseFloat(etrate.getText().toString());
                    float tenure = Float.parseFloat(ettenure.getText().toString());

                    // converting to proper data type
                    float p = loan;
                    float r = (rate) / 100;
                    float t = tenure;
                    float numberOfMonths = t * 12;

// calculating monthly EMI
                    double monthlyInterestRate = r / 12;
                    double numerator = Math.pow((1 + monthlyInterestRate), numberOfMonths);
                    double denominator = Math.pow((1 + monthlyInterestRate), numberOfMonths) - 1;
                    double emi = p * monthlyInterestRate * numerator / denominator;

                    // generating monthly breakup

                    StringBuilder breakup = new StringBuilder();
                    breakup.append("Monthly Breakup of EMI:\n");
                    double totalInterest = 0;
                    double totalAmountPaid = p + totalInterest;

                    // Calculate and display the breakup for each month
                    for (int i = 1; i <= numberOfMonths; i++) {
                        double interest = p * monthlyInterestRate;
                        double principal = emi - interest;
                        totalInterest += interest;
                        p-= principal;
                        breakup.append("Month ").append(i).append(": Balance amt (₹) = ").append(String.format("%.2f", p))
                                .append(", EMI (₹) = ").append(String.format("%.2f", emi))
                                .append(", Interest (₹) = ").append(String.format("%.2f", interest)).append("\n\n");
                    }
                    double totalEMI = emi * numberOfMonths;


                    String msg = "Loan Amount (₹) = " + loan
                            + "\nRate = " + rate + " %"
                            + "\nTenure = " + tenure + " years"
                            + "\nEMI (₹) = " + String.format("%.2f", emi)
                            + "\nTotal EMI (₹) = " + String.format("%.2f", totalEMI)
                            + "\nTotal Interest Paid (₹) = " + String.format("%.2f", totalInterest) +"\n\n";

                    Intent intent = new Intent(calculateemi.this, breakups.class);
                    intent.putExtra("msg", msg);
                    intent.putExtra("breakup", breakup.toString());
                    startActivity(intent);

                }
            }
        });

    }
}